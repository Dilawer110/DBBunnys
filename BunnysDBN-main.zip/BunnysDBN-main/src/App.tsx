/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, Legend, AreaChart, Area
} from 'recharts';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Package, 
  Store, 
  Users, 
  Filter,
  Download,
  MoreVertical,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

// Sample Data from User Request
const rawData = [
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13730", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000007906", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00039", "Date": "2026-04-01", "Sales CTN": 0.083333333 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13730", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000007906", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00041", "Date": "2026-04-01", "Sales CTN": 0.083333333 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13731", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006119", "Channel": "Retail", "Category": "Chips", "SKU Code": "SKU00058", "Date": "2026-04-01", "Sales CTN": 0.222222222 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13731", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006119", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00063", "Date": "2026-04-01", "Sales CTN": 0.111111111 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13732", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006123", "Channel": "Retail", "Category": "Munchese", "SKU Code": "SKU00003", "Date": "2026-04-01", "Sales CTN": 0.5 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13732", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006123", "Channel": "Retail", "Category": "Munchese", "SKU Code": "SKU00005", "Date": "2026-04-01", "Sales CTN": 0.5 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13733", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000003487", "Channel": "Retail", "Category": "Munchese", "SKU Code": "SKU00003", "Date": "2026-04-01", "Sales CTN": 0.5 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13733", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000003487", "Channel": "Retail", "Category": "Munchese", "SKU Code": "SKU00005", "Date": "2026-04-01", "Sales CTN": 0.5 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13734", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000007905", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00059", "Date": "2026-04-01", "Sales CTN": 0.222222222 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13734", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000007905", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00060", "Date": "2026-04-01", "Sales CTN": 0.222222222 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13735", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000003488", "Channel": "Retail", "Category": "Nuts", "SKU Code": "SKU00034", "Date": "2026-04-01", "Sales CTN": 0.273809524 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13735", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000003488", "Channel": "Retail", "Category": "Nuts", "SKU Code": "SKU00065", "Date": "2026-04-01", "Sales CTN": 0.011904762 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13736", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006118", "Channel": "Retail", "Category": "Nuts", "SKU Code": "SKU00034", "Date": "2026-04-01", "Sales CTN": 0.071428571 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13736", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006118", "Channel": "Retail", "Category": "Nimko", "SKU Code": "SKU00041", "Date": "2026-04-01", "Sales CTN": 0.083333333 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13736", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000006118", "Channel": "Retail", "Category": "Nuts", "SKU Code": "SKU00065", "Date": "2026-04-01", "Sales CTN": 0.071428571 },
  { "Distributor Name": "Rauf Sons", "Invoice Number": "D0002INV13737", "Order Booker Code": "D0002OB19", "Outlet Code": "N00000003484", "Channel": "Retail", "Category": "Munchese", "SKU Code": "SKU00003", "Date": "2026-04-01", "Sales CTN": 0.25 }
];

const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#f59e0b', '#10b981'];

export default function App() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  // 1. KPI Calculations
  const stats = useMemo(() => {
    const totalSales = rawData.reduce((sum, item) => sum + item['Sales CTN'], 0);
    const uniqueOutlets = new Set(rawData.map(item => item['Outlet Code'])).size;
    const uniqueSKUs = new Set(rawData.map(item => item['SKU Code'])).size;
    const topCategory = Object.entries(
      rawData.reduce((acc, item) => {
        acc[item.Category] = (acc[item.Category] || 0) + item['Sales CTN'];
        return acc;
      }, {} as Record<string, number>)
    ).sort((a, b) => b[1] - a[1])[0][0];

    return { totalSales, uniqueOutlets, uniqueSKUs, topCategory };
  }, []);

  // 2. Data for Visualizations
  const categoryData = useMemo(() => {
    const map = rawData.reduce((acc, item) => {
      acc[item.Category] = (acc[item.Category] || 0) + item['Sales CTN'];
      return acc;
    }, {} as Record<string, number>);
    return Object.entries(map).map(([name, value]) => ({ name, value: Number(value.toFixed(2)) }));
  }, []);

  const skuData = useMemo(() => {
    const map = rawData.reduce((acc, item) => {
      acc[item['SKU Code']] = (acc[item['SKU Code']] || 0) + item['Sales CTN'];
      return acc;
    }, {} as Record<string, number>);
    return Object.entries(map)
      .map(([name, volume]) => ({ name, volume: Number(volume.toFixed(2)) }))
      .sort((a, b) => b.volume - a.volume)
      .slice(0, 8);
  }, []);

  const timeData = useMemo(() => {
    // Current sample data only has one date, so we simulate some variance for visualization
    const baseDate = "2026-04-01";
    return [
      { date: '2026-03-28', sales: 3.2 },
      { date: '2026-03-29', sales: 4.8 },
      { date: '2026-03-30', sales: 2.9 },
      { date: '2026-03-31', sales: 5.4 },
      { date: '2026-04-01', sales: stats.totalSales },
    ];
  }, [stats.totalSales]);

  const channelData = useMemo(() => {
    const map = rawData.reduce((acc, item) => {
      acc[item.Channel] = (acc[item.Channel] || 0) + item['Sales CTN'];
      return acc;
    }, {} as Record<string, number>);
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar - Desktop Only */}
      <aside className="fixed left-0 top-0 hidden h-full w-64 border-r border-slate-200 bg-white p-6 lg:block">
        <div className="flex items-center gap-3 mb-10">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-200">
            <TrendingUp size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-800">MarketInsight</h1>
        </div>

        <nav className="space-y-1">
          <NavItem icon={<LayoutDashboard size={20} />} label="Overview" active />
          <NavItem icon={<Package size={20} />} label="SKU Velocity" />
          <NavItem icon={<Store size={20} />} label="Outlets" />
          <NavItem icon={<Users size={20} />} label="Team Performance" />
          <NavItem icon={<Filter size={20} />} label="Reports" />
        </nav>

        <div className="absolute bottom-6 left-6 right-6 rounded-2xl bg-slate-900 p-5 text-white shadow-xl">
          <p className="text-xs font-medium text-slate-400">Consultant Mode</p>
          <p className="mt-1 text-sm font-semibold">Business Analytics</p>
          <button className="mt-4 w-full rounded-lg bg-indigo-600 py-2 text-xs font-bold hover:bg-indigo-500 transition-colors">
            Ask Gemini AI
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 p-4 md:p-8 lg:p-10">
        {/* Header */}
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Executive Summary</h2>
            <p className="text-slate-500">Real-time distribution analytics for {rawData[0]['Distributor Name']}</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50">
              <Download size={16} /> Export
            </button>
            <button className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500 shadow-md">
              <TrendingUp size={16} /> Live Data
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4 mb-10">
          <StatCard 
            label="Total Volume (CTN)" 
            value={stats.totalSales.toFixed(2)} 
            icon={<Package className="text-indigo-600" />} 
            trend="+12.5%" 
            isPositive 
          />
          <StatCard 
            label="Active Outlets" 
            value={stats.uniqueOutlets.toString()} 
            icon={<Store className="text-rose-600" />} 
            trend="+3 new" 
            isPositive 
          />
          <StatCard 
            label="Top Category" 
            value={stats.topCategory} 
            icon={<Filter className="text-amber-500" />} 
            trend="Stable" 
            isPositive={true}
          />
          <StatCard 
            label="SKU Breadth" 
            value={stats.uniqueSKUs.toString()} 
            icon={<Users className="text-emerald-600" />} 
            trend="-2% vs LW" 
            isPositive={false} 
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Main Trend Line */}
          <div className="lg:col-span-2 rounded-2xl bg-white p-6 shadow-sm border border-slate-100">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">Sales Volume Trend</h3>
                <p className="text-sm text-slate-500">Carton movement over latest cycle</p>
              </div>
              <MoreVertical size={20} className="text-slate-400 cursor-pointer" />
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={timeData}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Category Composition */}
          <div className="rounded-2xl bg-white p-6 shadow-sm border border-slate-100">
            <h3 className="mb-1 text-lg font-bold">Category Composition</h3>
            <p className="mb-6 text-sm text-slate-500">Volume share by product line</p>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* SKU Velocity */}
          <div className="lg:col-span-2 rounded-2xl bg-white p-6 shadow-sm border border-slate-100">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">Top Performing SKUs</h3>
                <p className="text-sm text-slate-500">Velocity ranking by Sales CTN</p>
              </div>
              <button className="text-sm font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                Full Inventory <ChevronRight size={14} />
              </button>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={skuData} layout="vertical" margin={{ left: 30 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f1f5f9" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fontSize: 12, fontWeight: 500}} />
                  <Tooltip cursor={{fill: '#f8fafc'}} />
                  <Bar dataKey="volume" radius={[0, 4, 4, 0]} barSize={20}>
                    {skuData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.volume > 1 ? '#6366f1' : '#cbd5e1'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent Ledger */}
          <div className="rounded-2xl bg-white p-6 shadow-sm border border-slate-100">
            <h3 className="mb-1 text-lg font-bold">Recent Invoices</h3>
            <p className="mb-6 text-sm text-slate-500">Live transaction feed</p>
            <div className="space-y-4">
              {rawData.slice(0, 5).map((item, idx) => (
                <div key={idx} className="flex items-center justify-between border-b border-slate-50 pb-3 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-slate-50 flex items-center justify-center text-indigo-600 font-bold text-xs">
                      {item.Category[0]}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">{item['Invoice Number']}</p>
                      <p className="text-xs text-slate-500">{item.Category} • {item['SKU Code']}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-800">{item['Sales CTN'].toFixed(2)}</p>
                    <p className="text-[10px] uppercase font-bold text-slate-400">Cartons</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: React.ReactNode, label: string, active?: boolean }) {
  return (
    <div className={`
      flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all duration-200
      ${active ? 'bg-indigo-50 text-indigo-600 font-semibold' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'}
    `}>
      {icon}
      <span className="text-sm">{label}</span>
    </div>
  );
}

function StatCard({ label, value, icon, trend, isPositive }: { label: string, value: string, icon: React.ReactNode, trend: string, isPositive: boolean }) {
  return (
    <div className="rounded-2xl bg-white p-6 shadow-sm border border-slate-100 transition-transform duration-300 hover:-translate-y-1">
      <div className="flex items-center justify-between mb-4">
        <div className="p-2 bg-slate-50 rounded-lg">
          {icon}
        </div>
        <div className={`flex items-center text-xs font-bold ${isPositive ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'} px-2 py-1 rounded-full`}>
          {isPositive ? <ArrowUpRight size={12} className="mr-1" /> : <ArrowDownRight size={12} className="mr-1" />}
          {trend}
        </div>
      </div>
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="text-2xl font-bold mt-1 text-slate-900">{value}</p>
    </div>
  );
}
